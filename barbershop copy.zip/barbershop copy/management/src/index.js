const express = require('express');
const bodyParser = require('body-parser');
const sequelize = require('./config/database');
const listRoutes = require('./routes/list');

const app = express();
const port = process.env.PORT || 3002;



app.use('/appointment', listRoutes);

// Middleware
app.use(bodyParser.json());

// Test the database connection
sequelize.authenticate().then(() => {
    console.log('Connection has been established successfully.');
}).catch(err => {
    console.error('Unable to connect to the database:', err);
});

// Routes
app.get('/', (req, res) => {
    res.send('Hello World!');
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});

module.exports = app;
