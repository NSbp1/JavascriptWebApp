const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('Db name here', 'db username here', 'db password here', {
    host: 'localhost',
    dialect: 'postgres'
});

module.exports = sequelize;
