const express = require('express');
const bodyParser = require('body-parser');
const sequelize = require('./config/database');
const listRoutes = require('../../src/routes/list');
const cors = require("cors");
const app = express();

app.use(bodyParser.json());
app.use(cors());

const port = process.env.PORT || 3002;




// Middleware


// Test the database connection
sequelize.authenticate().then(() => {
    console.log('Connection has been established successfully.');
}).catch(err => {
    console.error('Unable to connect to the database:', err);
});

// Routes
app.use('/api/appointment', listRoutes); 

app.get('/', (req, res) => {
    res.send('Hello World!');
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});

module.exports = app;
