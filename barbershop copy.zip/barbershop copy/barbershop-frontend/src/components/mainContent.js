import React from 'react';


const MainContent = () => {
  return (
    <main style={styles.main}>
      <section style={styles.section}>
        <h2>Make an Appointment Now</h2>
    
        
      </section>
    </main>
  );
};

const styles = {
  main: {
    padding: '2rem',
    textAlign: 'center',
  },
  section: {
    marginBottom: '2rem',
  },
};

export default MainContent;
